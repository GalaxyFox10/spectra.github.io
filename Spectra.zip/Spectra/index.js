const { ForgeClient } = require("forgescript")
const { ForgeDB } = require("forgedb")
const { ForgeMusic } = require("forge-music")
const { colors} = require("colors")
// Client initialization
   const client = new ForgeClient({
    "intents": [
        "Guilds",
        "GuildMembers",
        "GuildModeration",
        "GuildEmojisAndStickers",
        "GuildIntegrations",
        "GuildWebhooks",
        "GuildInvites",
        "GuildVoiceStates",
        "GuildPresences",
        "GuildMessages",
        "GuildMessageReactions",
        "GuildMessageTyping",
        "DirectMessages",
        "DirectMessageReactions",
        "DirectMessageTyping",
        "MessageContent",
        "GuildScheduledEvents",
        "AutoModerationConfiguration",
        "AutoModerationExecution"
    ],
    "useInviteSystem": false,
    "prefixes": [
        "!",
        "?"
    ],
    "events": [
        "channelCreate",
        "channelDelete",
        "channelUpdate",
        "debug",
        "emojiCreate",
        "emojiDelete",
        "emojiUpdate",
        "error",
        "guildAuditLogEntryCreate",
        "guildCreate",
        "guildDelete",
        "guildMemberAdd",
        "guildMemberRemove",
        "guildMemberUpdate",
        "guildUpdate",
        "inviteCreate",
        "inviteDelete",
        "interactionCreate",
        "messageCreate",
        "messageDelete",
        "messageReactionAdd",
        "messageReactionRemove",
        "messageUpdate",
        "ready",
        "roleCreate",
        "roleDelete",
        "roleUpdate",
        "shardDisconnect",
        "shardError",
        "shardReady",
        "shardReconnecting",
        "shardResume",
        "userUpdate",
        "voiceStateUpdate"
    ],
    "extensions": [
        new ForgeDB(),
        new ForgeMusic({ soundsFolder: `${process.cwd()}/Sounds` })
    ]
})
   
// Your bot token
   client.login("MTE0MDI2MDI0NzEyNzIxMjA3Mg.GstuXQ.mfex74LXptQKJo3QItwF9u91cehqAQYO1wKVtY")

   client.commands.add = ({
    name: "ping",
    type: "messageCreate",
    code: `$let[msg;$sendMessage[$channelID;$description[Checking client latency...]
$color[FFFFFF];true]]
$let[1st;$ping]
$wait[1000]
$function[$editMessage[$channelID;$get[msg];$title[🏓 | Pong!]
$description[**Client Latency:** $get[1st]ms
**Roundtrip:** $math[$executionTime-1000]ms]
$color[FFFFFF]]]`
})