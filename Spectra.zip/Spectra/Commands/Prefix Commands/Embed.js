module.exports = [{
name: "embed",
    type: "messageCreate",
code: `
$setVar[embedMsg-$guildID;$authorID;$sendMessage[$channelID;$title[Embed Builder]
$description[Click on the drop down menu below to start creating the embed]
$addActionRow
$addStringSelectMenu[embedBuilder-$authorID]
$addOption[Title;Title for this embed;embedMakingTitle]
$addOption[Description;Description for this embed;embedMakingDescription]
$addOption[Image;Image for this embed;embedMakingImage]
$addOption[Thumbnail;Thumbnail for this embed;embedMakingThumbnail]
$addOption[Footer;Footer for this embed;embedMakingFooter]
$addOption[Footer URL;Footer URL for this embed;embedMakingFooterURL]
$addOption[Author;Author for this embed;embedMakingAuthor]
$addOption[Author URL;Author URL for this embed;embedMakingAuthorURL]
$addOption[Color;The color of this embed;embedMakingColor];true]]`
},
  {
  type: "interactionCreate",
  code: `$if[$customID==embedBuilder-$authorID;
    $if[$selectMenuValues[0]==embedMakingTitle;$setVar[embedMakingTitle-$guildID;$authorID;true]
  $setVar[embedTitleMsg-$guildID;$authorID;$sendMessage[$channelID;ok so, what should be the \`Title\` of this embed?;true]]]
 
  $if[$selectMenuValues[0]==embedMakingDescription;$setVar[embedMakingDescription-$guildID;$authorID;true]
  $setVar[embedDescriptionMsg-$guildID;$authorID;$sendMessage[$channelID;ok so, what should be the \`Description\` of this embed?;true]]]
 
  $if[$selectMenuValues[0]==embedMakingImage;$setVar[embedMakingImage-$guildID;$authorID;true]
  $setVar[embedImageMsg-$guildID;$authorID;$sendMessage[$channelID;ok so, what should be the \`Image\` of this embed?;true]]]
 
  $if[$selectMenuValues[0]==embedMakingThumbnail;$setVar[embedMakingThumbnail-$guildID;$authorID;true]
  $setVar[embedThumbnailMsg-$guildID;$authorID;$sendMessage[$channelID;ok so, what should be the \`Thumbnail\` of this embed?;true]]]
 
  $if[$selectMenuValues[0]==embedMakingFooter;$setVar[embedMakingFooter-$guildID;$authorID;true]
  $setVar[embedFooterMsg-$guildID;$authorID;$sendMessage[$channelID;ok so, what should be the \`Footer\` of this embed?;true]]]
 
  $if[$selectMenuValues[0]==embedMakingFooterURL;$setVar[embedMakingFooterURL-$guildID;$authorID;true]
  $setVar[embedFooterURLMsg-$guildID;$authorID;$sendMessage[$channelID;ok so, what should be the \`Footer Icon\` of this embed?;true]]]
 
    $if[$selectMenuValues[0]==embedMakingAuthor;$setVar[embedMakingAuthor-$guildID;$authorID;true]
  $setVar[embedAuthorMsg-$guildID;$authorID;$sendMessage[$channelID;ok so, what should be the \`Author\` of this embed?;true]]]
 
  $if[$selectMenuValues[0]==embedMakingAuthorURL;$setVar[embedMakingAuthorURL-$guildID;$authorID;true]
  $setVar[embedAuthorURLMsg-$guildID;$authorID;$sendMessage[$channelID;ok so, what should be the \`Author Icon\` of this embed?;true]]]
 
$if[$selectMenuValues[0]==embedMakingColor;$setVar[embedMakingColor-$guildID;$authorID;true]
$setVar[embedColorMsg-$guildID;$authorID;$sendMessage[$channelID;ok so, what should be the \`Color\` of this embed?;true]]]
 
$function[$djsEval[ctx.interaction.deferUpdate()]]]
 
 
 
$if[$customID==embedFinish-$authorID;$setVar[embedFinished-$guildID;$authorID;true]
$setVar[embedFinishedMsg-$guildID;$authorID;$sendMessage[$channelID;Done!, $username I have completed the embed now please tell me the channel I have to send this embed;true]]
 
$function[$djsEval[ctx.interaction.deferUpdate()]]]`
},
                 {
    type: "messageCreate",
    code: `
$if[$getVar[embedMakingTitle-$guildID;$authorID]==true;$let[msg;$getVar[embedMsg-$guildID;$authorID]]
$setVar[title;$get[msg];$message]
$!editMessage[$channelID;$get[msg];$title[$getVar[title;$get[msg]]]
$description[$if[$getVar[description;$get[msg]]!=;$getVar[description;$get[msg]];Description]]
$footer[$getVar[footer;$get[msg]];$getVar[footerIcon;$get[msg]]]
$author[$getVar[author;$get[msg]];$getVar[authorIcon;$get[msg]]]
$image[$getVar[image;$get[msg]]]
$color[$getVar[color;$get[msg]]]
$if[$getVar[thumbnail;$get[msg]]!=;$thumbnail[$getVar[thumbnail;$get[msg]]];]
$setVar[embedMakingTitle-$guildID;$authorID;false]
$!deleteMessage[$channelID;$messageID;$getVar[embedTitleMsg-$guildID;$authorID]]
 
$addActionRow
$addStringSelectMenu[embedBuilder-$authorID]
$addOption[Title;Title for this embed;embedMakingTitle]
$addOption[Description;Description for this embed;embedMakingDescription]
$addOption[Image;Image for this embed;embedMakingImage]
$addOption[Thumbnail;Thumbnail for this embed;embedMakingThumbnail]
$addOption[Footer;Footer for this embed;embedMakingFooter]
$addOption[Footer URL;Footer URL for this embed;embedMakingFooterURL]
$addOption[Author;Author for this embed;embedMakingAuthor]
$addOption[Author URL;Author URL for this embed;embedMakingAuthorURL]
$addOption[Color;The color of this embed;embedMakingColor]
$addActionRow
$addButton[embedFinish-$authorID;Finish;Secondary]]]
 
 
 
 
 
 
 
 
 
 
$if[$getVar[embedMakingDescription-$guildID;$authorID]==true;$let[msg;$getVar[embedMsg-$guildID;$authorID]]
$setVar[description;$get[msg];$message]
$!editMessage[$channelID;$get[msg];$title[$if[$getVar[title;$get[msg]]!=;$getVar[title;$get[msg]];Title]]
$description[$if[$getVar[description;$get[msg]]!=;$getVar[description;$get[msg]];Description]]
$footer[$getVar[footer;$get[msg]];$getVar[footerIcon;$get[msg]]]
$author[$getVar[author;$get[msg]];$getVar[authorIcon;$get[msg]]]
$image[$getVar[image;$get[msg]]]
$color[$getVar[color;$get[msg]]]
$if[$getVar[thumbnail;$get[msg]]!=;$thumbnail[$getVar[thumbnail;$get[msg]]];]
$setVar[embedMakingDescription-$guildID;$authorID;false]
$!deleteMessage[$channelID;$messageID;$getVar[embedDescriptionMsg-$guildID;$authorID]]
 
$addActionRow
$addStringSelectMenu[embedBuilder-$authorID]
$addOption[Title;Title for this embed;embedMakingTitle]
$addOption[Description;Description for this embed;embedMakingDescription]
$addOption[Image;Image for this embed;embedMakingImage]
$addOption[Thumbnail;Thumbnail for this embed;embedMakingThumbnail]
$addOption[Footer;Footer for this embed;embedMakingFooter]
$addOption[Footer URL;Footer URL for this embed;embedMakingFooterURL]
$addOption[Author;Author for this embed;embedMakingAuthor]
$addOption[Author URL;Author URL for this embed;embedMakingAuthorURL]
$addOption[Color;The color of this embed;embedMakingColor]
$addActionRow
$addButton[embedFinish-$authorID;Finish;Secondary]]]
 
 
 
 
$if[$getVar[embedMakingImage-$guildID;$authorID]==true;$let[msg;$getVar[embedMsg-$guildID;$authorID]]
$setVar[image;$get[msg];$message]
$!editMessage[$channelID;$get[msg];
$title[$if[$getVar[title;$get[msg]]!=;$getVar[title;$get[msg]];Title]]
$description[$if[$getVar[description;$get[msg]]!=;$getVar[description;$get[msg]];Description]]
$footer[$getVar[footer;$get[msg]];$getVar[footerIcon;$get[msg]]]
$author[$getVar[author;$get[msg]];$getVar[authorIcon;$get[msg]]]
$image[$getVar[image;$get[msg]]]
$color[$getVar[color;$get[msg]]]
$if[$getVar[thumbnail;$get[msg]]!=;$thumbnail[$getVar[thumbnail;$get[msg]]];]
$setVar[embedMakingImage-$guildID;$authorID;false]
$!deleteMessage[$channelID;$messageID;$getVar[embedImageMsg-$guildID;$authorID]]
 
$addActionRow
$addStringSelectMenu[embedBuilder-$authorID]
$addOption[Title;Title for this embed;embedMakingTitle]
$addOption[Description;Description for this embed;embedMakingDescription]
$addOption[Image;Image for this embed;embedMakingImage]
$addOption[Thumbnail;Thumbnail for this embed;embedMakingThumbnail]
$addOption[Footer;Footer for this embed;embedMakingFooter]
$addOption[Footer URL;Footer URL for this embed;embedMakingFooterURL]
$addOption[Author;Author for this embed;embedMakingAuthor]
$addOption[Author URL;Author URL for this embed;embedMakingAuthorURL]
$addOption[Color;The color of this embed;embedMakingColor]
$addActionRow
$addButton[embedFinish-$authorID;Finish;Secondary]]]
 
 
 
 
$if[$getVar[embedMakingThumbnail-$guildID;$authorID]==true;$let[msg;$getVar[embedMsg-$guildID;$authorID]]
$setVar[thumbnail;$get[msg];$message]
$!editMessage[$channelID;$get[msg];$title[$if[$getVar[title;$get[msg]]!=;$getVar[title;$get[msg]];Title]]
$description[$if[$getVar[description;$get[msg]]!=;$getVar[description;$get[msg]];Description]]
$footer[$getVar[footer;$get[msg]];$getVar[footerIcon;$get[msg]]]
$author[$getVar[author;$get[msg]];$getVar[authorIcon;$get[msg]]]
$image[$getVar[image;$get[msg]]]
$color[$getVar[color;$get[msg]]]
$if[$getVar[thumbnail;$get[msg]]!=;$thumbnail[$getVar[thumbnail;$get[msg]]];]
$setVar[embedMakingThumbnail-$guildID;$authorID;false]
$!deleteMessage[$channelID;$messageID;$getVar[embedThumbnailMsg-$guildID;$authorID]]
 
$addActionRow
$addStringSelectMenu[embedBuilder-$authorID]
$addOption[Title;Title for this embed;embedMakingTitle]
$addOption[Description;Description for this embed;embedMakingDescription]
$addOption[Image;Image for this embed;embedMakingImage]
$addOption[Thumbnail;Thumbnail for this embed;embedMakingThumbnail]
$addOption[Footer;Footer for this embed;embedMakingFooter]
$addOption[Footer URL;Footer URL for this embed;embedMakingFooterURL]
$addOption[Author;Author for this embed;embedMakingAuthor]
$addOption[Author URL;Author URL for this embed;embedMakingAuthorURL]
$addOption[Color;The color of this embed;embedMakingColor]
$addActionRow
$addButton[embedFinish-$authorID;Finish;Secondary]]]
 
 
 
$if[$getVar[embedMakingFooter-$guildID;$authorID]==true;$let[msg;$getVar[embedMsg-$guildID;$authorID]]
$setVar[footer;$get[msg];$message]
$!editMessage[$channelID;$get[msg];
$title[$if[$getVar[title;$get[msg]]!=;$getVar[title;$get[msg]];Title]]
$description[$if[$getVar[description;$get[msg]]!=;$getVar[description;$get[msg]];Description]]
$footer[$getVar[footer;$get[msg]];$getVar[footerIcon;$get[msg]]]
$author[$getVar[author;$get[msg]];$getVar[authorIcon;$get[msg]]]
$image[$getVar[image;$get[msg]]]
$color[$getVar[color;$get[msg]]]
$if[$getVar[thumbnail;$get[msg]]!=;$thumbnail[$getVar[thumbnail;$get[msg]]];]
$setVar[embedMakingFooter-$guildID;$authorID;false]
$!deleteMessage[$channelID;$messageID;$getVar[embedFooterMsg-$guildID;$authorID]]
 
$addActionRow
$addStringSelectMenu[embedBuilder-$authorID]
$addOption[Title;Title for this embed;embedMakingTitle]
$addOption[Description;Description for this embed;embedMakingDescription]
$addOption[Image;Image for this embed;embedMakingImage]
$addOption[Thumbnail;Thumbnail for this embed;embedMakingThumbnail]
$addOption[Footer;Footer for this embed;embedMakingFooter]
$addOption[Footer URL;Footer URL for this embed;embedMakingFooterURL]
$addOption[Author;Author for this embed;embedMakingAuthor]
$addOption[Author URL;Author URL for this embed;embedMakingAuthorURL]
$addOption[Color;The color of this embed;embedMakingColor]
$addActionRow
$addButton[embedFinish-$authorID;Finish;Secondary]]]
 
 
 
 
$if[$getVar[embedMakingFooterURL-$guildID;$authorID]==true;$let[msg;$getVar[embedMsg-$guildID;$authorID]]
$setVar[footerIcon;$get[msg];$message]
$!editMessage[$channelID;$get[msg];
$title[$if[$getVar[title;$get[msg]]!=;$getVar[title;$get[msg]];Title]]
$description[$if[$getVar[description;$get[msg]]!=;$getVar[description;$get[msg]];Description]]
$footer[$getVar[footer;$get[msg]];$getVar[footerIcon;$get[msg]]]
$author[$getVar[author;$get[msg]];$getVar[authorIcon;$get[msg]]]
$image[$getVar[image;$get[msg]]]
$color[$getVar[color;$get[msg]]]
$if[$getVar[thumbnail;$get[msg]]!=;$thumbnail[$getVar[thumbnail;$get[msg]]];]
$setVar[embedMakingFooterURL-$guildID;$authorID;false]
$!deleteMessage[$channelID;$messageID;$getVar[embedFooterURLMsg-$guildID;$authorID]]
 
$addActionRow
$addStringSelectMenu[embedBuilder-$authorID]
$addOption[Title;Title for this embed;embedMakingTitle]
$addOption[Description;Description for this embed;embedMakingDescription]
$addOption[Image;Image for this embed;embedMakingImage]
$addOption[Thumbnail;Thumbnail for this embed;embedMakingThumbnail]
$addOption[Footer;Footer for this embed;embedMakingFooter]
$addOption[Footer URL;Footer URL for this embed;embedMakingFooterURL]
$addOption[Author;Author for this embed;embedMakingAuthor]
$addOption[Author URL;Author URL for this embed;embedMakingAuthorURL]
$addOption[Color;The color of this embed;embedMakingColor]
$addActionRow
$addButton[embedFinish-$authorID;Finish;Secondary]]]
 
 
 
$if[$getVar[embedMakingAuthor-$guildID;$authorID]==true;$let[msg;$getVar[embedMsg-$guildID;$authorID]]
$setVar[author;$get[msg];$message]
$!editMessage[$channelID;$get[msg];
$title[$if[$getVar[title;$get[msg]]!=;$getVar[title;$get[msg]];Title]]
$description[$if[$getVar[description;$get[msg]]!=;$getVar[description;$get[msg]];Description]]
$footer[$getVar[footer;$get[msg]];$getVar[footerIcon;$get[msg]]]
$author[$getVar[author;$get[msg]];$getVar[authorIcon;$get[msg]]]
$image[$getVar[image;$get[msg]]]
$color[$getVar[color;$get[msg]]]
$if[$getVar[thumbnail;$get[msg]]!=;$thumbnail[$getVar[thumbnail;$get[msg]]];]
$setVar[embedMakingAuthor-$guildID;$authorID;false]
$!deleteMessage[$channelID;$messageID;$getVar[embedAuthorMsg-$guildID;$authorID]]
 
$addActionRow
$addStringSelectMenu[embedBuilder-$authorID]
$addOption[Title;Title for this embed;embedMakingTitle]
$addOption[Description;Description for this embed;embedMakingDescription]
$addOption[Image;Image for this embed;embedMakingImage]
$addOption[Thumbnail;Thumbnail for this embed;embedMakingThumbnail]
$addOption[Footer;Footer for this embed;embedMakingFooter]
$addOption[Footer URL;Footer URL for this embed;embedMakingFooterURL]
$addOption[Author;Author for this embed;embedMakingAuthor]
$addOption[Author URL;Author URL for this embed;embedMakingAuthorURL]
$addOption[Color;The color of this embed;embedMakingColor]
$addActionRow
$addButton[embedFinish-$authorID;Finish;Secondary]]]
 
 
 
 
$if[$getVar[embedMakingAuthorURL-$guildID;$authorID]==true;$let[msg;$getVar[embedMsg-$guildID;$authorID]]
$setVar[authorIcon;$get[msg];$message]
$!editMessage[$channelID;$get[msg];
$title[$if[$getVar[title;$get[msg]]!=;$getVar[title;$get[msg]];Title]]
$description[$if[$getVar[description;$get[msg]]!=;$getVar[description;$get[msg]];Description]]
$footer[$getVar[footer;$get[msg]];$getVar[footerIcon;$get[msg]]]
$author[$getVar[author;$get[msg]];$getVar[authorIcon;$get[msg]]]
$image[$getVar[image;$get[msg]]]
$color[$getVar[color;$get[msg]]]
$if[$getVar[thumbnail;$get[msg]]!=;$thumbnail[$getVar[thumbnail;$get[msg]]];]
$setVar[embedMakingAuthorURL-$guildID;$authorID;false]
$!deleteMessage[$channelID;$messageID;$getVar[embedAuthorURLMsg-$guildID;$authorID]]
 
$addActionRow
$addStringSelectMenu[embedBuilder-$authorID]
$addOption[Title;Title for this embed;embedMakingTitle]
$addOption[Description;Description for this embed;embedMakingDescription]
$addOption[Image;Image for this embed;embedMakingImage]
$addOption[Thumbnail;Thumbnail for this embed;embedMakingThumbnail]
$addOption[Footer;Footer for this embed;embedMakingFooter]
$addOption[Footer URL;Footer URL for this embed;embedMakingFooterURL]
$addOption[Author;Author for this embed;embedMakingAuthor]
$addOption[Author URL;Author URL for this embed;embedMakingAuthorURL]
$addOption[Color;The color of this embed;embedMakingColor]
$addActionRow
$addButton[embedFinish-$authorID;Finish;Secondary]]]
 
 
$if[$getVar[embedMakingColor-$guildID;$authorID]==true;$let[msg;$getVar[embedMsg-$guildID;$authorID]]
$setVar[color;$get[msg];$toTitleCase[$message]]
$!editMessage[$channelID;$get[msg];
$title[$if[$getVar[title;$get[msg]]!=;$getVar[title;$get[msg]];Title]]
$description[$if[$getVar[description;$get[msg]]!=;$getVar[description;$get[msg]];Description]]
$footer[$getVar[footer;$get[msg]];$getVar[footerIcon;$get[msg]]]
$author[$getVar[author;$get[msg]];$getVar[authorIcon;$get[msg]]]
$image[$getVar[image;$get[msg]]]
$color[$getVar[color;$get[msg]]]
$if[$getVar[thumbnail;$get[msg]]!=;$thumbnail[$getVar[thumbnail;$get[msg]]];]
$setVar[embedMakingColor-$guildID;$authorID;false]
$!deleteMessage[$channelID;$messageID;$getVar[embedColorMsg-$guildID;$authorID]]
 
$addActionRow
$addStringSelectMenu[embedBuilder-$authorID]
$addOption[Title;Title for this embed;embedMakingTitle]
$addOption[Description;Description for this embed;embedMakingDescription]
$addOption[Image;Image for this embed;embedMakingImage]
$addOption[Thumbnail;Thumbnail for this embed;embedMakingThumbnail]
$addOption[Footer;Footer for this embed;embedMakingFooter]
$addOption[Footer URL;Footer URL for this embed;embedMakingFooterURL]
$addOption[Author;Author for this embed;embedMakingAuthor]
$addOption[Author URL;Author URL for this embed;embedMakingAuthorURL]
$addOption[Color;The color of this embed;embedMakingColor]
 
$addActionRow
$addButton[embedFinish-$authorID;Finish;Secondary]]]
 
 
 
$if[$getVar[embedFinished-$guildID;$authorID]==true;$if[$guildChannelExists[$guildID;$message]==true;$let[channel;$message]]
$if[$guildChannelExists[$guildID;$mentionedChannels[0;true]]==true;$let[channel;$mentionedChannels[0;true]]]
$let[msg;$getVar[embedMsg-$guildID;$authorID]]
$if[$guildChannelExists[$guildID;$get[channel]]==true;
$let[msg2;$sendMessage[$get[channel];$if[$getVar[title;$get[msg]]!=;$title[$getVar[title;$get[msg]]];]
$if[$getVar[description;$get[msg]]!=;$description[$getVar[description;$get[msg]]];]
$if[$getVar[thumbnail;$get[msg]]!=;$thumbnail[$getVar[thumbnail;$get[msg]]];]
$footer[$getVar[footer;$get[msg]];$getVar[footerIcon;$get[msg]]]
$author[$getVar[author;$get[msg]];$getVar[authorIcon;$get[msg]]]
$image[$getVar[image;$get[msg]]]
$color[$getVar[color;$get[msg]]];true]]
 
$description[I have sent the embed in <#$get[channel]>]
$addActionRow
$addButton[https://discord.com/$guildID/$get[channel]/$get[msg2];Jump to message;Link]$setVar[embedFinished-$guildID;$authorID;false];$reply No such channel exists]]`
           }]