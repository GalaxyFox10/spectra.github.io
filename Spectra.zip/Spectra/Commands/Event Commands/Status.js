module.exports = {
    code: `$setInterval[$setStatus[online;Watching;$abbreviateNumber[$userCount] users in $guildCount guilds.];15000]`,
    type: "ready" // The event to act on
}