module.exports = {
    name: "updatecmnd",
    aliases: ["update", "cmnd", "up"],
    type: "messageCreate",
    code: `$if[$authorID==$botOwnerID;
        $updateCommands
        $updateApplicationCommands
        $function[$addMessageReactions[$channelID;$messageID;✅]]
        ]`
}