module.exports = {
    name: "work",
    type: "messageCreate",
    aliases: ["pay"],
    code:  `
$cooldown[Work-$authorID;3h;
$description[Your shift is not for another $parseMS[$getCooldownTime[Work-$authorID]]]]
$title[Dummy Money Earned]
$description[Heyo bro you earned $let[Money;$randomNumber[100;2500;false]] $get[Money]]
$footer[All in a hard days work]
$setVar[money;$authorID;$math[$get[Money]+$getVar[money;$authorID]]]
$color[004d66]`
}